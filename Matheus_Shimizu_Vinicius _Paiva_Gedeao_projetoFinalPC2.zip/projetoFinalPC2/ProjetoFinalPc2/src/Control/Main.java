/**
 *
 * @author Matheus Shimizu, Vinicius Paiva, Gedeão Pereira Lima
 * 
 */
package Control;

public class Main {

    public static void main(String[] args) {
        ControlEntrar controlEntrar = new ControlEntrar();
    }
}
